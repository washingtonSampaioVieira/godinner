package godinner.resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import godinner.repository.CidadeRepository;




@RestController
@RequestMapping("/cidade")
public class CidadeResource {
	
	@Autowired
	CidadeRepository cidadeRepository;

	@GetMapping
	public String teste() {
		return "teste";
	}
	
}
