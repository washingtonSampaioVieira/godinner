package godinner.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import godinner.model.Restaurante;
import godinner.repository.RestauranteRepository;

@RestController
@RequestMapping("/restaurante")
public class RestauranteResource {
	
	@Autowired
	RestauranteRepository restauranteRepository;
	
	@GetMapping
	public String teste() {
		return "teste"; 
	}
	
	@GetMapping("/teste")
	public List<Restaurante> getRestaurantes(){
		System.out.println("'Olaa");
		return restauranteRepository.findAll();
	}
}
