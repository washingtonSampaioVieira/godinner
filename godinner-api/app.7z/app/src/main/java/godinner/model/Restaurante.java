package godinner.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import godinner.model.Endereco;


@Entity
@Table(name = "tbl_restaurante")
public class Restaurante {
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_restaurante")
    Integer id;
	
    @Size(max = 100 , min = 8)
	@Column(name = "email")
    @NotNull
    String email;
    
    @Size(max = 255 , min = 8)
	@Column(name = "senha")
    @NotNull
    String senha;
    
    @Size(max = 50 , min = 2)
	@Column(name = "razao_social")
    @NotNull
    String razaoSocial;
    
    @Size(max = 18 , min = 18)
	@Column(name = "cnpj")
    @NotNull
    String cnpj;
	
    @Size(max = 13 , min = 13)
	@Column(name = "telefone")
    String telefone;
    
	@OneToOne
	@JoinColumn(name = "id_endereco")
    @NotNull
    Endereco endereco;
	
    @Size(max = 1 , min = 1)
	@Column(name = "status")
    @NotNull
    char status;
	
	@Column(name = "criacao")
    @NotNull
    String criacao;
	
	@Column(name = "ultima_atualizacao")
    @NotNull
    String ultimaAtualizacao;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getRazaoSocial() {
		return razaoSocial;
	}

	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public String getCriacao() {
		return criacao;
	}

	public void setCriacao(String criacao) {
		this.criacao = criacao;
	}

	public String getUltimaAtualizacao() {
		return ultimaAtualizacao;
	}

	public void setUltimaAtualizacao(String ultimaAtualizacao) {
		this.ultimaAtualizacao = ultimaAtualizacao;
	}

	@Override
	public String toString() {
		return "Restaurante [id=" + id + ", email=" + email + ", senha=" + senha + ", razaoSocial=" + razaoSocial
				+ ", cnpj=" + cnpj + ", telefone=" + telefone + ", endereco=" + endereco + ", status=" + status
				+ ", criacao=" + criacao + ", ultimaAtualizacao=" + ultimaAtualizacao + ", getId()=" + getId()
				+ ", getEmail()=" + getEmail() + ", getSenha()=" + getSenha() + ", getRazaoSocial()=" + getRazaoSocial()
				+ ", getCnpj()=" + getCnpj() + ", getTelefone()=" + getTelefone() + ", getEndereco()=" + getEndereco()
				+ ", getStatus()=" + getStatus() + ", getCriacao()=" + getCriacao() + ", getUltimaAtualizacao()="
				+ getUltimaAtualizacao() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	
	
	
}
