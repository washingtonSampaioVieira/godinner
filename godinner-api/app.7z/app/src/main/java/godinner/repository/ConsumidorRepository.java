package godinner.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import godinner.model.Consumidor;

public interface ConsumidorRepository extends JpaRepository<Consumidor, Long> {
	
}
